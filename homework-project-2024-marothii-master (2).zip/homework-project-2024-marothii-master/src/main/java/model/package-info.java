/**
 * Provides model classes for setting and getting behaviour of the game.
 */
package model;
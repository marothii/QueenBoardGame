/**
 * Provides classes for controlling the game using the model.
 */
package controllers;